package com.example.myasset

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query


@Dao
interface AssetDao{
    @Insert
   suspend fun insertAsset(asset: Asset)
    @Delete
   suspend fun deleteAsset(asset: Asset)

}
