package com.example.myasset

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AllInbox
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.BottomEnd
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddNewAssetScreen(modifier: Modifier = Modifier) {
    var name by remember { mutableStateOf("") }
    var serialNumber by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Available") }
    var lastUpdatedLocation by remember { mutableStateOf("") }
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = {
                // Implement the action to add a new asset
            }) {
                Icon(Icons.Filled.Save, contentDescription = "Save")
            }
        }
    ){innerpadding->
        Column(modifier = modifier.padding(innerpadding)) {
            OutlinedButton(onClick = { /* Handle insert image */ }) {
                Text("Insert Image")
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Name", modifier = Modifier.weight(1f))
                TextField(value = name, onValueChange = { name = it }, modifier = Modifier.weight(1f))
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Serial Number", modifier = Modifier.weight(1f))
                TextField(value = serialNumber, onValueChange = { serialNumber = it }, modifier = Modifier.weight(1f))
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Category", modifier = Modifier.weight(1f))
                TextField(value = category, onValueChange = { category = it }, modifier = Modifier.weight(1f))
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Last Updated Location", modifier = Modifier.weight(1f))
                TextField(value = lastUpdatedLocation, onValueChange = { lastUpdatedLocation = it }, modifier = Modifier.weight(1f))
            }

        }
        
    
    }
}
@Preview(showBackground = true)
@Composable
fun PreviewAddNewAssetScreen() {
    AddNewAssetScreen()
}