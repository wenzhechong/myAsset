package com.example.myasset

import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity
data class Assets(
    @PrimaryKey
    val serial: String,
    val name: String,
    val status: Number,
    val holder: String
)
